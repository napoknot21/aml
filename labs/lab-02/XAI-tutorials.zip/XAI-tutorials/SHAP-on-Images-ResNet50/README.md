# Application-of-SHAP-values-INTERNSHIP

This is the repository for my intership subject. The application of SHAP values on the image dataset (ResNet50), and on the tabular dataset (Adult dataset). Also to explain and describe all the graphs of SHAP in the Jupyter Notebook.